<?php
require("class_GeraTabela.php");
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://api.football-data.org/v2/competitions/2021/standings",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "X-Auth-Token: a14000a6d2dc4a0698b97414a53220f6"
  ),
));

$response = json_decode(curl_exec($curl), true);
$err = curl_error($curl);

curl_close($curl);

$obj = new GeraTabela(); // chama class que tem metodos para manipularmos os dados

$data = array();
foreach ($response['standings'][0]['table'] as $key => $value) {

  $data[$key]["team"] = $value['team']['name'];
  $data[$key]["v"] = $value['won'];
  $data[$key]["d"] = $value['lost'];
  $data[$key]["e"] = $value['draw'];
  $data[$key]["g_marcados"] = $value['goalsFor'];
  $data[$key]["g_sofridos"] = $value['goalsAgainst'];
  $data[$key]["pontos"] = $obj->somaPontos($value['won'], $value['draw']);
  $data[$key]["diff_golos"] = $obj->cDiffGolos($value['goalsFor'], $value['goalsAgainst']);

}

$data = $obj->ordenaPontos($data, "pontos", "DESC");

//var_dump($data);

$fp = fopen('output.json', 'w');
fwrite($fp, json_encode($data));
fclose($fp);

?>
