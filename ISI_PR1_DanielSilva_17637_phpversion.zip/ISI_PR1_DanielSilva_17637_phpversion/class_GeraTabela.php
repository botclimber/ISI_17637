<?php
require_once("iGeraTabela.php");

class GeraTabela implements iGeraTabela {

  function __construct(){}

  public function somaPontos($vitorias, $empates){

    return ($vitorias * self::X)+$empates;
  }

  public function cDiffGolos($golosMarcados, $golosSofridos){

    return ($golosMarcados - $golosSofridos);
  }

public function ordenaPontos($dados, $campo, $ordem = "ASC" /* Crescente Defaut */ ){
    // ordena dados pelo campo x pela ordem y (Crescente ou Decrescente)
    // neste caso ordena se pelo campo pontos
    $aux = 0;

    for($x = 0; $x < count($dados); $x++){
      for($y = $x + 1; $y < count($dados); $y++){
        if( ($dados[$y][$campo] > $dados[$x][$campo] && !strcmp($ordem, "DESC")) || ($dados[$y][$campo] < $dados[$x][$campo] && !strcmp($ordem, "ASC")) ){

          $aux = $dados[$y];
          $dados[$y] = $dados[$x];
          $dados[$x] = $aux;

        }
      }
    }

    return $dados;
  }

}

?>
